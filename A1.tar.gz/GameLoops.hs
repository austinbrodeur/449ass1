module GameLoops (
	startGame,
	gameLoop,
	stratsPrint,
	stratsList,
	intMode,
	checkModes
) where


import ApocTools
import ApocStrategyHuman
--import ApocStrategyDefensive
--import ApocStrategyOffensive
import Data.List
import Data.Maybe (fromJust, isNothing)
import Checks


-- Returns strategies
stratsPrint :: String
stratsPrint = "\nStrategies:\n  offensive\n  defensive\n  human\n"

stratsList :: [String]
stratsList = ["offensive", "defensive", "human"]

-- Interactive mode. Shows strategies and gets user input.
intMode :: IO()
intMode = do
  putStrLn ("\nEnter one of the strategies following strategies for each challenger:\n" ++ stratsPrint)
  putStrLn "Enter the black strategy: "
  blackStrat <- getLine
  putStrLn "Enter the white strategy: "
  whiteStrat <- getLine
  checkModes blackStrat whiteStrat

-- Checks if the input from either interactive mode or normal mode is correct and runs the game if it is.
checkModes :: String -> String -> IO()
checkModes bas was = do
  let ba = inputToString bas
  let wa = inputToString was
  if (isNothing ba) || (isNothing wa)
    then putStrLn stratsPrint
    else startGame (fst (fromJust ba)) (snd (fromJust ba)) (fst (fromJust wa)) (snd (fromJust wa))
    


--
inputToString :: String -> Maybe (Chooser, String)
inputToString strat | (strat == "human") = Just (human, strat)
         --  | (strat == "offensive") = Just (offensive, strat)
         --  | (strat == "defensive") = Just (defensive, strat)
           | otherwise = Nothing


-- Dummy for main loop. Replace with main loop when ready.
startGame :: Chooser -> String -> Chooser -> String -> IO()
startGame ba bas wa was = do
                let board = initBoard

		gameLoop board ba bas wa was


gameLoop :: GameState -> Chooser -> String -> Chooser -> String -> IO()
gameLoop board ba bas wa was = do -- a = AI, s = strat
    black <- ba (board) Normal Black 
    white <- wa (board) Normal White

    let whitePieces = [WP, WP, WP, WP, WP, WK, WK]
    let blackPieces = [BP, BP, BP, BP, BP, BK, BK]
    let newboard = GameState (if black == Nothing
				  then Passed
      				  else if isValidMove black Black board 
                            	      then Played (head (fromJust black), head (tail (fromJust black)))--first player move
                       	     	      else Goofed (head (fromJust black), head (tail (fromJust black))))
                             (blackPen board + if ((isValidMove black Black board) == False) then 1 else 0)
                             (if white==Nothing
                                then Passed
                                else if isValidMove white White board 
                                  then Played (head (fromJust white), head (tail (fromJust white)))
                                  else Goofed (head (fromJust white), head (tail (fromJust white)))) --Second player move
                             (whitePen board + if ((isValidMove white White board) == False) then 1 else 0)
                             (if (black==Nothing || isValidMove black Black board == False)
                                then (if white==Nothing || isValidMove white White board == False then (theBoard board) else (replace2 (replace2 (theBoard board)
                                                 ((fromJust white) !! 1)
                                                 (getFromBoard (theBoard board) ((fromJust white) !! 0)))
                                                 ((fromJust white) !! 0)
                                                 E))
                                else (if white==Nothing || isValidMove white White board == False then (replace2 (replace2 (theBoard board)
                                                 ((fromJust black) !! 1)
                                                 (getFromBoard (theBoard board) ((fromJust black) !! 0)))
                                       ((fromJust black) !! 0) E)
                                        else if samePawnMove (fromJust black) (fromJust white)
                                          then (replace2
                                                  (replace2
                                                      (replace2
                                                          (theBoard board) ((fromJust white) !! 0) E)
                                                  ((fromJust black) !! 0) E)
                                            ((fromJust black) !! 1) (whichCellWins (theBoard board) (fromJust black) (fromJust white)))
                                          else (replace2
                                                  (replace2
                                                    (replace2
                                                      (replace2
                                                        (theBoard board) ((fromJust white) !! 0) E)
                                                      ((fromJust black) !! 0) E)
                                                    ((fromJust white) !! 1) (getFromBoard (theBoard board) ((fromJust white) !! 0)))
                                                  ((fromJust black) !! 1) (getFromBoard (theBoard board) ((fromJust black) !! 0)))
                                          ))
                                            
 

                                          
    putStrLn $ (show newboard) 
    if ((black == Nothing) && (white == Nothing) || isNothing (checkEndGame newboard whitePieces blackPieces))
    then putStrLn("!")
    else gameLoop newboard ba bas wa was





isValidMove     :: Maybe[(Int, Int)] -> Player -> GameState -> Bool
isValidMove Nothing p b = True
isValidMove m p b =  
    if isInBoundsforLists m then
        if first==E || (p == White && (first==BK || first==BP)) || (p == Black && (first==WK || first==WP))
            then False 
            else if (first==BK || first==WK) then checkKnightValidMove m b else checkPawnValidMove m p b
    else False
    where first = (getFromBoard (theBoard b) ((fromJust m) !! 0))

{-
--if the bool is true keep going
gameLoop :: GameState -> String -> String -> PlayerPieces -> PlayerPieces -> IO()
gameLoop board pw pb wp bp = do


				white <- (if (pw == "offensive")
					     then human board Normal White
					     else if (pw == "defensive")
					             then human board Normal White
						     else human board Normal White )

				black <- (if (pb == "offensive")
					     then human board Normal Black
					     else if (pb == "defensive")
					            then human board Normal Black
						    else human board Normal Black )
				putStrLn $ show board

				if (black == Nothing)
				   then blackPlay board = Passed
				   else if (fst (head (fromJust (black))) == -1)
				           then blackPlay board = Goofed ((head (tail (fromJust black))), (head (head (tail (fromJust black)))))
					   else blackPlay board = Played ((head (fromJust black)), (head (tail (fromJust black))))
				
				if (white == Nothing)
				   then let whitePlay board = Passed
				   else if (fst (head (fromJust (white))) == -1)
				           then let whitePlay board = Goofed ((head (tail (fromJust white))), (head (head (tail (fromJust white)))))
					   else let whitePlay board = Played ((head (fromJust white)), (head (tail (fromJust white))))

				if (blackPlay board == Goofed)
				   then let blackPen board += 1
			  	   else let blackPen board += 0
				
				if (whitePlay board == Goofed)
				   then whitePen board += 1
			  	   else whitePen board += 0

				if (checkValidCapture (theBoard board) (head (tail (fromJust white)))
				   then v1 <- capture ((getFromBoard board (head (fromJust white))) (getFromBoard board (head (tail (fromJust white))))
			
				if (checkValidCapture (theBoard board) (head (tail (fromJust black)))
				   then v2 <- capture ((getFromBoard board (head (fromJust black))) (getFromBoard board (head (tail (fromJust black))))

				--movements //replacing shit
		
				let winner = (checkEndGame board wp bp) 
				if (winner /= Nothing)
				   then do
					putStrLn $ show board
					putStrLn $ "Holy Fuck, " ++ winner ++ " just won!"
				   else (gameLoop board pw pb wp bp)
-}


---2D list utility functions-------------------------------------------------------

-- | Replaces the nth element in a row with a new element.
replace         :: [a] -> Int -> a -> [a]
replace xs n elem = let (ys,zs) = splitAt n xs
                     in (if null zs then (if null ys then [] else init ys) else ys)
                        ++ [elem]
                        ++ (if null zs then [] else tail zs)

-- | Replaces the (x,y)th element in a list of lists with a new element.
replace2        :: [[a]] -> (Int,Int) -> a -> [[a]]
replace2 xs (x,y) elem = replace xs y (replace (xs !! y) x elem)











